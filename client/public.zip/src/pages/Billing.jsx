import TableView from "./TableView";

const Billing = () => {
  return (
    <div className="">
      {/* <h2 className="text-2xl font-semibold mb-4">Billing</h2>
      <p>Here you can see all paid/unpaid invoices and generate bills.</p> */}
      {/* <TableView /> */}
    </div>
  );
};

export default Billing;
