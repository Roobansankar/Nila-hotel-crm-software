//correct
// import React, { useEffect, useState } from "react";

// const MenuPage = () => {
//   const [foodCategories, setFoodCategories] = useState(() => {
//     return JSON.parse(localStorage.getItem("foodCategories")) || [];
//   });

//   const [itemsByCategory, setItemsByCategory] = useState(() => {
//     return JSON.parse(localStorage.getItem("itemsByCategory")) || {};
//   });

//   const [priceMap, setPriceMap] = useState(() => {
//     return JSON.parse(localStorage.getItem("priceMap")) || {};
//   });

//   const [selectedCategory, setSelectedCategory] = useState(() => {
//     return JSON.parse(localStorage.getItem("foodCategories"))?.[0] || "";
//   });

//   const [newItemName, setNewItemName] = useState("");
//   const [newItemPrice, setNewItemPrice] = useState("");
//   const [newCategory, setNewCategory] = useState("");
//   const [editingItemIndex, setEditingItemIndex] = useState(null);
//   const [editedItemName, setEditedItemName] = useState("");
//   const [editedItemPrice, setEditedItemPrice] = useState("");

//   // Save to localStorage
//   useEffect(() => {
//     localStorage.setItem("foodCategories", JSON.stringify(foodCategories));
//   }, [foodCategories]);

//   useEffect(() => {
//     localStorage.setItem("itemsByCategory", JSON.stringify(itemsByCategory));
//   }, [itemsByCategory]);

//   useEffect(() => {
//     localStorage.setItem("priceMap", JSON.stringify(priceMap));
//   }, [priceMap]);

//   const handleAddItem = () => {
//     if (!newItemName.trim() || !newItemPrice.trim()) {
//       alert("Enter both item name and price");
//       return;
//     }

//     if (itemsByCategory[selectedCategory]?.includes(newItemName)) {
//       alert("Item already exists in this category");
//       return;
//     }

//     const updatedItems = {
//       ...itemsByCategory,
//       [selectedCategory]: [
//         ...(itemsByCategory[selectedCategory] || []),
//         newItemName,
//       ],
//     };

//     setItemsByCategory(updatedItems);
//     setPriceMap({ ...priceMap, [newItemName]: Number(newItemPrice) });
//     setNewItemName("");
//     setNewItemPrice("");
//   };

//   const handleDeleteItem = (item) => {
//     const updatedItems = {
//       ...itemsByCategory,
//       [selectedCategory]: itemsByCategory[selectedCategory].filter(
//         (i) => i !== item
//       ),
//     };

//     const updatedPrices = { ...priceMap };
//     delete updatedPrices[item];

//     setItemsByCategory(updatedItems);
//     setPriceMap(updatedPrices);
//   };

//   const handleEditItem = (item, index) => {
//     setEditingItemIndex(index);
//     setEditedItemName(item);
//     setEditedItemPrice(priceMap[item]);
//   };

//   const handleSaveEdit = (originalItem) => {
//     if (!editedItemName.trim() || !editedItemPrice) {
//       alert("Enter valid name and price");
//       return;
//     }

//     const updatedItemsList = [...itemsByCategory[selectedCategory]];
//     updatedItemsList[editingItemIndex] = editedItemName;

//     const updatedItems = {
//       ...itemsByCategory,
//       [selectedCategory]: updatedItemsList,
//     };

//     const updatedPrices = { ...priceMap };
//     delete updatedPrices[originalItem];
//     updatedPrices[editedItemName] = Number(editedItemPrice);

//     setItemsByCategory(updatedItems);
//     setPriceMap(updatedPrices);
//     setEditingItemIndex(null);
//     setEditedItemName("");
//     setEditedItemPrice("");
//   };

//   const handleAddCategory = () => {
//     const cat = newCategory.trim();
//     if (!cat) return alert("Enter a category name");
//     if (foodCategories.includes(cat)) return alert("Category already exists");

//     const updated = [...foodCategories, cat];
//     setFoodCategories(updated);
//     setItemsByCategory({ ...itemsByCategory, [cat]: [] });
//     setSelectedCategory(cat);
//     setNewCategory("");
//   };

//   const handleDeleteCategory = (cat) => {
//     if (!window.confirm(`Delete category "${cat}"?`)) return;

//     const updatedCategories = foodCategories.filter((c) => c !== cat);
//     const updatedItems = { ...itemsByCategory };
//     const updatedPrices = { ...priceMap };

//     (updatedItems[cat] || []).forEach((item) => {
//       delete updatedPrices[item];
//     });

//     delete updatedItems[cat];

//     setFoodCategories(updatedCategories);
//     setItemsByCategory(updatedItems);
//     setPriceMap(updatedPrices);

//     if (cat === selectedCategory) {
//       setSelectedCategory(updatedCategories[0] || "");
//     }
//   };

//   return (
//     <div className="p-4 max-w-4xl mx-auto">
//       <h2 className="text-2xl font-bold mb-6">Menu Management</h2>

//       {/* Add Category Section */}
//       <div className="mt-10 flex flex-wrap items-center gap-2 mb-5">
//         <input
//           type="text"
//           placeholder="New Category"
//           value={newCategory}
//           onChange={(e) => setNewCategory(e.target.value)}
//           className="border p-2 flex-grow"
//         />
//         <button
//           onClick={handleAddCategory}
//           className="bg-blue-600 text-white px-4 py-2 rounded"
//         >
//           Add Category
//         </button>
//       </div>

//       {/* Category Dropdown */}

//       <div className="mb-4 flex flex-wrap items-center gap-2">
//         <select
//           value={selectedCategory}
//           onChange={(e) => setSelectedCategory(e.target.value)}
//           className="border p-2 flex-grow"
//         >
//           {foodCategories.map((cat) => (
//             <option key={cat} value={cat}>
//               {cat}
//             </option>
//           ))}
//         </select>
//         {selectedCategory && (
//           <button
//             onClick={() => handleDeleteCategory(selectedCategory)}
//             className="bg-red-500 text-white px-4 py-2 rounded"
//           >
//             Delete Category
//           </button>
//         )}
//       </div>

//       {/* Add Item */}
//       <div className="mb-6 flex flex-wrap gap-2">
//         <input
//           type="text"
//           placeholder="Item Name"
//           value={newItemName}
//           onChange={(e) => setNewItemName(e.target.value)}
//           className="border p-2 flex-grow"
//         />
//         <input
//           type="number"
//           placeholder="Price"
//           value={newItemPrice}
//           onChange={(e) => setNewItemPrice(e.target.value)}
//           className="border p-2 w-28"
//         />
//         <button
//           onClick={handleAddItem}
//           className="bg-green-600 text-white px-4 py-2 rounded"
//         >
//           Add Item
//         </button>
//       </div>

//       {/* Table */}
//       <div className="overflow-x-auto">
//         <table className="min-w-full border text-sm">
//           <thead>
//             <tr className="bg-gray-100">
//               <th className="p-2 border">Item</th>
//               <th className="p-2 border">Price</th>
//               <th className="p-2 border w-40">Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {(itemsByCategory[selectedCategory] || []).map((item, index) => (
//               <tr key={item}>
//                 <td className="p-2 border">
//                   {editingItemIndex === index ? (
//                     <input
//                       value={editedItemName}
//                       onChange={(e) => setEditedItemName(e.target.value)}
//                       className="border p-1 w-full"
//                     />
//                   ) : (
//                     item
//                   )}
//                 </td>
//                 <td className="p-2 border">
//                   {editingItemIndex === index ? (
//                     <input
//                       type="number"
//                       value={editedItemPrice}
//                       onChange={(e) => setEditedItemPrice(e.target.value)}
//                       className="border p-1 w-24"
//                     />
//                   ) : (
//                     priceMap[item]
//                   )}
//                 </td>
//                 <td className="p-2 border flex gap-1">
//                   {editingItemIndex === index ? (
//                     <button
//                       onClick={() => handleSaveEdit(item)}
//                       className="bg-blue-600 text-white px-2 py-1 rounded text-xs"
//                     >
//                       Save
//                     </button>
//                   ) : (
//                     <button
//                       onClick={() => handleEditItem(item, index)}
//                       className="bg-yellow-500 text-white px-2 py-1 rounded text-xs"
//                     >
//                       Edit
//                     </button>
//                   )}
//                   <button
//                     onClick={() => handleDeleteItem(item)}
//                     className="bg-red-500 text-white px-2 py-1 rounded text-xs"
//                   >
//                     Delete
//                   </button>
//                 </td>
//               </tr>
//             ))}
//             {(itemsByCategory[selectedCategory] || []).length === 0 && (
//               <tr>
//                 <td colSpan="3" className="text-center text-gray-500 p-3">
//                   No items in this category.
//                 </td>
//               </tr>
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// };

// export default MenuPage;

import React, { useEffect, useState } from "react";

const MenuPage = () => {
  const [foodCategories, setFoodCategories] = useState(() => {
    return JSON.parse(localStorage.getItem("foodCategories")) || [];
  });

  const [itemsByCategory, setItemsByCategory] = useState(() => {
    return JSON.parse(localStorage.getItem("itemsByCategory")) || {};
  });

  const [priceMap, setPriceMap] = useState(() => {
    return JSON.parse(localStorage.getItem("priceMap")) || {};
  });

  const [selectedCategory, setSelectedCategory] = useState(
    foodCategories[0] || ""
  );
  const [newItemName, setNewItemName] = useState("");
  const [newItemPrice, setNewItemPrice] = useState("");
  const [newCategory, setNewCategory] = useState("");
  const [editingIndex, setEditingIndex] = useState(null);
  const [editedItemName, setEditedItemName] = useState("");
  const [editedItemPrice, setEditedItemPrice] = useState("");

  useEffect(() => {
    localStorage.setItem("foodCategories", JSON.stringify(foodCategories));
    localStorage.setItem("itemsByCategory", JSON.stringify(itemsByCategory));
    localStorage.setItem("priceMap", JSON.stringify(priceMap));
  }, [foodCategories, itemsByCategory, priceMap]);

  const handleAddCategory = () => {
    if (!newCategory.trim()) return alert("Enter a category name");
    if (foodCategories.includes(newCategory)) return alert("Category exists");
    const updated = [...foodCategories, newCategory];
    setFoodCategories(updated);
    setItemsByCategory({ ...itemsByCategory, [newCategory]: [] });
    setSelectedCategory(newCategory);
    setNewCategory("");
  };

  const handleDeleteCategory = () => {
    if (!window.confirm(`Delete category "${selectedCategory}"?`)) return;
    const updatedCategories = foodCategories.filter(
      (c) => c !== selectedCategory
    );
    const updatedItems = { ...itemsByCategory };
    const updatedPrices = { ...priceMap };
    (updatedItems[selectedCategory] || []).forEach(
      (item) => delete updatedPrices[item]
    );
    delete updatedItems[selectedCategory];
    setFoodCategories(updatedCategories);
    setItemsByCategory(updatedItems);
    setPriceMap(updatedPrices);
    setSelectedCategory(updatedCategories[0] || "");
  };

  const handleAddItem = () => {
    if (!newItemName.trim() || !newItemPrice)
      return alert("Enter item name and price");
    const currentItems = itemsByCategory[selectedCategory] || [];
    if (currentItems.includes(newItemName)) return alert("Item already exists");
    const updated = [...currentItems, newItemName];
    setItemsByCategory({ ...itemsByCategory, [selectedCategory]: updated });
    setPriceMap({ ...priceMap, [newItemName]: Number(newItemPrice) });
    setNewItemName("");
    setNewItemPrice("");
  };

  const handleDeleteItem = (item) => {
    const filtered = itemsByCategory[selectedCategory].filter(
      (i) => i !== item
    );
    const updatedPrices = { ...priceMap };
    delete updatedPrices[item];
    setItemsByCategory({ ...itemsByCategory, [selectedCategory]: filtered });
    setPriceMap(updatedPrices);
  };

  const handleEditItem = (item, index) => {
    setEditingIndex(index);
    setEditedItemName(item);
    setEditedItemPrice(priceMap[item]);
  };

  const handleSaveItem = (originalItem) => {
    const updatedList = [...itemsByCategory[selectedCategory]];
    updatedList[editingIndex] = editedItemName;
    const updatedPrices = { ...priceMap };
    delete updatedPrices[originalItem];
    updatedPrices[editedItemName] = Number(editedItemPrice);
    setItemsByCategory({ ...itemsByCategory, [selectedCategory]: updatedList });
    setPriceMap(updatedPrices);
    setEditingIndex(null);
  };

  return (
    // <div className="p-6 max-w-4xl mx-auto space-y-6">
    //   <h1 className="text-3xl font-bold text-center">
    //     🍽️ Restaurant Menu Management
    //   </h1>

    //   {/* Category Management */}
    //   <div className="bg-white p-4 rounded shadow space-y-4">
    //     <h2 className="text-xl font-semibold">Category Management</h2>
    //     <div className="flex flex-wrap gap-2">
    //       <input
    //         type="text"
    //         placeholder="New Category"
    //         value={newCategory}
    //         onChange={(e) => setNewCategory(e.target.value)}
    //         className="border p-2 flex-1 rounded"
    //       />
    //       <button
    //         onClick={handleAddCategory}
    //         className="bg-blue-600 text-white px-4 py-2 rounded"
    //       >
    //         Add Category
    //       </button>
    //     </div>

    //     {foodCategories.length > 0 && (
    //       <div className="flex flex-wrap gap-2 items-center">
    //         <select
    //           value={selectedCategory}
    //           onChange={(e) => setSelectedCategory(e.target.value)}
    //           className="border p-2 rounded flex-1"
    //         >
    //           {foodCategories.map((cat) => (
    //             <option key={cat}>{cat}</option>
    //           ))}
    //         </select>
    //         <button
    //           onClick={handleDeleteCategory}
    //           className="bg-red-600 text-white px-4 py-2 rounded"
    //         >
    //           Delete Category
    //         </button>
    //       </div>
    //     )}
    //   </div>

    //   {/* Item Management */}
    //   {selectedCategory && (
    //     <div className="bg-white p-4 rounded shadow space-y-4">
    //       <h2 className="text-xl font-semibold">
    //         Manage Items in{" "}
    //         <span className="text-blue-700">{selectedCategory}</span>
    //       </h2>
    //       <div className="flex flex-wrap gap-2">
    //         <input
    //           type="text"
    //           placeholder="Item Name"
    //           value={newItemName}
    //           onChange={(e) => setNewItemName(e.target.value)}
    //           className="border p-2 rounded flex-1"
    //         />
    //         <input
    //           type="number"
    //           placeholder="Price"
    //           value={newItemPrice}
    //           onChange={(e) => setNewItemPrice(e.target.value)}
    //           className="border p-2 rounded w-32"
    //         />
    //         <button
    //           onClick={handleAddItem}
    //           className="bg-green-600 text-white px-4 py-2 rounded"
    //         >
    //           Add Item
    //         </button>
    //       </div>

    //       {/* Table */}
    //       <div className="overflow-x-auto">
    //         <table className="w-full text-sm border">
    //           <thead className="bg-gray-100">
    //             <tr>
    //               <th className="border p-2 text-left">Item</th>
    //               <th className="border p-2 text-left">Price</th>
    //               <th className="border p-2 text-left">Actions</th>
    //             </tr>
    //           </thead>
    //           <tbody>
    //             {(itemsByCategory[selectedCategory] || []).map(
    //               (item, index) => (
    //                 <tr key={item} className="border-t">
    //                   <td className="p-2">
    //                     {editingIndex === index ? (
    //                       <input
    //                         value={editedItemName}
    //                         onChange={(e) => setEditedItemName(e.target.value)}
    //                         className="border rounded p-1 w-full"
    //                       />
    //                     ) : (
    //                       item
    //                     )}
    //                   </td>
    //                   <td className="p-2">
    //                     {editingIndex === index ? (
    //                       <input
    //                         type="number"
    //                         value={editedItemPrice}
    //                         onChange={(e) => setEditedItemPrice(e.target.value)}
    //                         className="border rounded p-1 w-24"
    //                       />
    //                     ) : (
    //                       `₹${priceMap[item]}`
    //                     )}
    //                   </td>
    //                   <td className="p-2 space-x-2">
    //                     {editingIndex === index ? (
    //                       <>
    //                         <button
    //                           onClick={() => handleSaveItem(item)}
    //                           className="bg-blue-500 text-white px-3 py-1 rounded"
    //                         >
    //                           Save
    //                         </button>
    //                         <button
    //                           onClick={() => setEditingIndex(null)}
    //                           className="bg-gray-400 text-white px-3 py-1 rounded"
    //                         >
    //                           Cancel
    //                         </button>
    //                       </>
    //                     ) : (
    //                       <>
    //                         <button
    //                           onClick={() => handleEditItem(item, index)}
    //                           className="bg-yellow-500 text-white px-3 py-1 rounded"
    //                         >
    //                           Edit
    //                         </button>
    //                         <button
    //                           onClick={() => handleDeleteItem(item)}
    //                           className="bg-red-500 text-white px-3 py-1 rounded"
    //                         >
    //                           Delete
    //                         </button>
    //                       </>
    //                     )}
    //                   </td>
    //                 </tr>
    //               )
    //             )}
    //             {(itemsByCategory[selectedCategory] || []).length === 0 && (
    //               <tr>
    //                 <td colSpan="3" className="text-center text-gray-500 p-4">
    //                   No items in this category.
    //                 </td>
    //               </tr>
    //             )}
    //           </tbody>
    //         </table>
    //       </div>
    //     </div>
    //   )}
    // </div>
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-center">
        🍽️ Restaurant Menu Management
      </h1>

      {/* Combined Flex Row */}
      <div className="flex flex-col md:flex-row gap-6">
        {/* Category Management */}
        <div className="bg-white p-4 rounded shadow w-full md:w-1/2 space-y-4">
          <h2 className="text-xl font-semibold">Category Management</h2>
          <div className="flex flex-wrap gap-2">
            <input
              type="text"
              placeholder="New Category"
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              className="border p-2 flex-1 rounded"
            />
            <button
              onClick={handleAddCategory}
              className="bg-blue-600 text-white px-4 py-2 rounded"
            >
              Add Category
            </button>
          </div>

          {foodCategories.length > 0 && (
            <div className="flex flex-wrap gap-2 items-center">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="border p-2 rounded flex-1"
              >
                {foodCategories.map((cat) => (
                  <option key={cat}>{cat}</option>
                ))}
              </select>
              <button
                onClick={handleDeleteCategory}
                className="bg-red-600 text-white px-4 py-2 rounded"
              >
                Delete Category
              </button>
            </div>
          )}
        </div>

        {/* Item Management */}
        {selectedCategory && (
          <div className="bg-white p-4 rounded shadow w-full md:w-1/2 space-y-4">
            <h2 className="text-xl font-semibold">
              Manage Items in{" "}
              <span className="text-blue-700">{selectedCategory}</span>
            </h2>
            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                placeholder="Item Name"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                className="border p-2 rounded flex-1"
              />
              <input
                type="number"
                placeholder="Price"
                value={newItemPrice}
                onChange={(e) => setNewItemPrice(e.target.value)}
                className="border p-2 rounded w-32"
              />
              <button
                onClick={handleAddItem}
                className="bg-green-600 text-white px-4 py-2 rounded"
              >
                Add Item
              </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm border">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border p-2 text-left">Item</th>
                    <th className="border p-2 text-left">Price</th>
                    <th className="border p-2 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(itemsByCategory[selectedCategory] || []).map(
                    (item, index) => (
                      <tr key={item} className="border-t">
                        <td className="p-2">
                          {editingIndex === index ? (
                            <input
                              value={editedItemName}
                              onChange={(e) =>
                                setEditedItemName(e.target.value)
                              }
                              className="border rounded p-1 w-full"
                            />
                          ) : (
                            item
                          )}
                        </td>
                        <td className="p-2">
                          {editingIndex === index ? (
                            <input
                              type="number"
                              value={editedItemPrice}
                              onChange={(e) =>
                                setEditedItemPrice(e.target.value)
                              }
                              className="border rounded p-1 w-24"
                            />
                          ) : (
                            `₹${priceMap[item]}`
                          )}
                        </td>
                        <td className="p-2 space-x-2">
                          {editingIndex === index ? (
                            <>
                              <button
                                onClick={() => handleSaveItem(item)}
                                className="bg-blue-500 text-white px-3 py-1 rounded"
                              >
                                Save
                              </button>
                              <button
                                onClick={() => setEditingIndex(null)}
                                className="bg-gray-400 text-white px-3 py-1 rounded"
                              >
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => handleEditItem(item, index)}
                                className="bg-yellow-500 text-white px-3 py-1 rounded"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => handleDeleteItem(item)}
                                className="bg-red-500 text-white px-3 py-1 rounded"
                              >
                                Delete
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    )
                  )}
                  {(itemsByCategory[selectedCategory] || []).length === 0 && (
                    <tr>
                      <td colSpan="3" className="text-center text-gray-500 p-4">
                        No items in this category.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MenuPage;
