import React, { useState, useEffect } from "react";
import { useParams, useLocation, useNavigate } from "react-router-dom";
// import Sidebar from "../components/Home/Sidebar";
import ItemsSection from "../Home/ItemsSection";
import CartSection from "../Home/CartSection";
import AddCategoryModal from "../Home/AddCategoryModal";
import AddItemModal from "../Home/AddItemModal";
import InvoiceModal from "../Home/InvoiceModal";
import Sidebar from "./Sidebar";

const Home = ({ handleLogout }) => {
  const [open, setOpen] = useState(() => window.innerWidth >= 768);
  const [selectedCategory, setSelectedCategory] = useState("Tiffin");
  const [cart, setCart] = useState({});
  const [searchText, setSearchText] = useState("");
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showItemModal, setShowItemModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerMobile, setCustomerMobile] = useState("");
  const [customerGST, setCustomerGST] = useState("");
  const [isPrinting, setIsPrinting] = useState(false);
  const [newCategory, setNewCategory] = useState("");
  const [newItemName, setNewItemName] = useState("");
  const [newItemPrice, setNewItemPrice] = useState("");

  const { tableId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const initialStatus = location.state?.status || "blank";
  const [status, setStatus] = useState(initialStatus);
  const [tableStatuses, setTableStatuses] = useState({});

  const cgstRate = 2.5;
  const sgstRate = 2.5;

  useEffect(() => {
    const handleResize = () => {
      setOpen(window.innerWidth >= 768);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem(`cart-${tableId}`));
    const savedStatus = localStorage.getItem(`status-${tableId}`);
    if (savedCart) setCart(savedCart);
    if (savedStatus) setStatus(savedStatus);
  }, [tableId]);

  const [foodCategories, setFoodCategories] = useState(() => {
    return (
      JSON.parse(localStorage.getItem("foodCategories")) || [
        "Tiffin",
        "Combo",
        "Rice Items",
        "Biryani",
        "Parotta Corner",
        "Snacks",
        "Beverages",
        "Chinese",
        "Desserts",
        "Juices",
        "South Indian",
        "North Indian",
      ]
    );
  });

  const [itemsByCategory, setItemsByCategory] = useState(() => {
    return (
      JSON.parse(localStorage.getItem("itemsByCategory")) || {
        Tiffin: ["Dosai", "Idli", "Vada"],
        Combo: ["Combo 1", "Combo 2"],
        "Rice Items": ["Sambar Rice", "Curd Rice"],
      }
    );
  });

  const [priceMap, setPriceMap] = useState(() => {
    return (
      JSON.parse(localStorage.getItem("priceMap")) || {
        Dosai: 30,
        Idli: 20,
        Vada: 15,
        "Combo 1": 70,
        "Combo 2": 80,
        "Sambar Rice": 40,
        "Curd Rice": 35,
      }
    );
  });

  useEffect(() => {
    localStorage.setItem("foodCategories", JSON.stringify(foodCategories));
  }, [foodCategories]);

  useEffect(() => {
    localStorage.setItem("itemsByCategory", JSON.stringify(itemsByCategory));
  }, [itemsByCategory]);

  useEffect(() => {
    localStorage.setItem("priceMap", JSON.stringify(priceMap));
  }, [priceMap]);

  const handleUpdateStatus = (newStatus) => {
    setStatus(newStatus);

    if (newStatus === "paid") {
      setCart({});
      localStorage.removeItem(`cart-${tableId}`);
      localStorage.removeItem(`status-${tableId}`);
    } else {
      localStorage.setItem(`status-${tableId}`, newStatus);
      localStorage.setItem(`cart-${tableId}`, JSON.stringify(cart));

      // 👇 Add this only when status is "running"
      if (newStatus === "running" && Object.keys(cart).length > 0) {
        const existingKOTs = JSON.parse(localStorage.getItem("kots") || "[]");
        const nextKOTNumber = existingKOTs.length + 1;

        const kotEntry = {
          kotNumber: nextKOTNumber,
          tableId,
          items: Object.keys(cart).map((item) => ({
            name: item,
            quantity: cart[item],
          })),
          createdAt: new Date().toISOString(),
        };

        const updatedKOTs = [...existingKOTs, kotEntry];
        localStorage.setItem("kots", JSON.stringify(updatedKOTs));
      }
    }
  };

  const handleAddToCart = (item) => {
    const newCart = { ...cart, [item]: (cart[item] || 0) + 1 };
    setCart(newCart);
    localStorage.setItem(`cart-${tableId}`, JSON.stringify(newCart));
  };

  const handleQuantityChange = (item, change) => {
    const newQty = (cart[item] || 0) + change;
    const updatedCart = { ...cart };
    if (newQty <= 0) delete updatedCart[item];
    else updatedCart[item] = newQty;
    setCart(updatedCart);
    localStorage.setItem(`cart-${tableId}`, JSON.stringify(updatedCart));
  };

  const handleDeleteCategory = (categoryToDelete) => {
    const updatedCategories = foodCategories.filter(
      (cat) => cat !== categoryToDelete
    );
    setFoodCategories(updatedCategories);
    if (selectedCategory === categoryToDelete) {
      setSelectedCategory(updatedCategories[0] || "");
    }
    const updatedItems = { ...itemsByCategory };
    delete updatedItems[categoryToDelete];
    setItemsByCategory(updatedItems);
  };

  const handleDeleteItem = (itemToDelete) => {
    const updatedItems = { ...itemsByCategory };
    const items = updatedItems[selectedCategory] || [];
    updatedItems[selectedCategory] = items.filter(
      (item) => item !== itemToDelete
    );
    setItemsByCategory(updatedItems);

    const updatedPriceMap = { ...priceMap };
    delete updatedPriceMap[itemToDelete];
    setPriceMap(updatedPriceMap);
  };

  const getPrice = (item) => priceMap[item] || 50;

  const filteredCategories = foodCategories.filter((cat) =>
    cat.toLowerCase().includes(searchText.toLowerCase())
  );

  const matchedCategory = foodCategories.find(
    (cat) => cat.toLowerCase().trim() === searchText.toLowerCase().trim()
  );

  return (
    <div className="flex flex-col md:flex-row h-screen">
      <Sidebar
        handleLogout={handleLogout}
        open={open}
        setOpen={setOpen}
        foodCategories={filteredCategories}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        handleDeleteCategory={handleDeleteCategory}
        setShowCategoryModal={setShowCategoryModal}
      />

      <div className="flex-1 flex flex-col md:flex-row">
        <ItemsSection
          tableId={tableId}
          selectedCategory={selectedCategory}
          matchedCategory={matchedCategory}
          searchText={searchText}
          setSearchText={setSearchText}
          items={
            matchedCategory
              ? itemsByCategory[matchedCategory] || []
              : searchText.trim()
              ? Object.entries(itemsByCategory).flatMap(([category, items]) =>
                  items.filter((item) =>
                    item.toLowerCase().includes(searchText.toLowerCase())
                  )
                )
              : itemsByCategory[selectedCategory] || []
          }
          handleAddToCart={handleAddToCart}
          handleDeleteItem={handleDeleteItem}
          getPrice={getPrice}
          setShowItemModal={setShowItemModal}
          setOpen={setOpen}
        />

        <CartSection
          cart={cart}
          setCart={setCart}
          status={status}
          handleQuantityChange={handleQuantityChange}
          handleUpdateStatus={handleUpdateStatus}
          getPrice={getPrice}
          tableId={tableId}
          setShowInvoiceModal={setShowInvoiceModal}
          setInvoiceNumber={setInvoiceNumber}
        />
      </div>

      <AddCategoryModal
        show={showCategoryModal}
        onClose={() => setShowCategoryModal(false)}
        newCategory={newCategory}
        setNewCategory={setNewCategory}
        foodCategories={foodCategories}
        setFoodCategories={setFoodCategories}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
      />

      <AddItemModal
        show={showItemModal}
        onClose={() => setShowItemModal(false)}
        selectedCategory={selectedCategory}
        newItemName={newItemName}
        setNewItemName={setNewItemName}
        newItemPrice={newItemPrice}
        setNewItemPrice={setNewItemPrice}
        setItemsByCategory={setItemsByCategory}
        setPriceMap={setPriceMap}
      />

      <InvoiceModal
        show={showInvoiceModal}
        onClose={() => setShowInvoiceModal(false)}
        cart={cart}
        getPrice={getPrice}
        handleUpdateStatus={handleUpdateStatus}
        tableId={tableId}
        invoiceNumber={invoiceNumber}
        setInvoiceNumber={setInvoiceNumber}
        customerName={customerName}
        setCustomerName={setCustomerName}
        customerMobile={customerMobile}
        setCustomerMobile={setCustomerMobile}
        customerGST={customerGST}
        setCustomerGST={setCustomerGST}
        isPrinting={isPrinting}
        setIsPrinting={setIsPrinting}
        cgstRate={cgstRate}
        sgstRate={sgstRate}
      />
    </div>
  );
};

export default Home;
