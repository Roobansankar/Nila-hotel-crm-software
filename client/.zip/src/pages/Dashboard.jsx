import TableView from "./TableView";

const Dashboard = () => {
  return (
    <div>
      {/* <h2 className="text-2xl font-semibold mb-4">Dashboard</h2>
      <p>Overview of today's orders, paid bills, and table usage.</p> */}
      <TableView />
    </div>
  );
};

export default Dashboard;
